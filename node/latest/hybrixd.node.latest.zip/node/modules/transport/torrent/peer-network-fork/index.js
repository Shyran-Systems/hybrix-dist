/**
 * @author Josaias Moura 
 * @author Agent725 (prototype further modified)
 */

'use strict';

const PeerNetwork = require('./lib/peer-network.js');

module.exports = PeerNetwork;
module.exports.PeerNetwork = PeerNetwork;
