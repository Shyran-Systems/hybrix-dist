// exports
exports.handleIds = [];
exports.handles = {};
exports.endpoints = [];
exports.peersURIs = {};
