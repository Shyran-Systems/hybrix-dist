# cli4ioc
Command line client for IoC

Instructions for use:

1. cd cli4ioc

2. git clone https://github.com/internetofcoins/nodejs-runtime 

3. ln -s ./nodejs-runtime/node64 node (for 64 bit, adjust for 32 bit or ARM)
